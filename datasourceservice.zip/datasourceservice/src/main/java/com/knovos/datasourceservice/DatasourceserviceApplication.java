package com.knovos.datasourceservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatasourceserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatasourceserviceApplication.class, args);
	}

}
